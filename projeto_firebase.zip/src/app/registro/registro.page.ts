import { Component, OnInit } from '@angular/core';
import {FirebaseService} from "../services/firebase.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {

  constructor(private firebaseService: FirebaseService,
              private router: Router) { }

  ngOnInit() {
  }

  async registrar(email, senha, nome) {
    await this.firebaseService.registrar(email, senha, nome);
    this.router.navigateByUrl('home');
  }

}
