import {Component, OnInit, ViewChild} from '@angular/core';
import {FirebaseService} from "../services/firebase.service";
import {Router} from "@angular/router";
import {filter} from "rxjs/operators";

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit{

  public notas;

  public usuario;

  @ViewChild('titulo', {static: true}) titulo;
  @ViewChild('nota', {static: true}) anotacao;

  public idAlteracao;


  constructor(private firebaseService: FirebaseService,
              private router: Router) {

  }

  ngOnInit() {
    //this.notas = this.firebaseService.getNotas();

    this.firebaseService.getUsuarioAutenticado().pipe(filter(usuario => usuario != undefined)).subscribe(usuario => {
      this.usuario = usuario;
      this.firebaseService.getNotas().subscribe(notas => {
        console.log(notas);
        this.notas = notas;
      });
    })

  }

  public selecionarNota(nota) {
    this.titulo.value = nota.titulo;
    this.anotacao.value = nota.anotacao;
    this.idAlteracao = nota.id;
  }

  public async adicionarNota(titulo, nota) {
    await this.firebaseService.adicionarNota(titulo.value, nota.value);
  }

  public async excluirNota(idNota) {
    await this.firebaseService.removerNota(idNota);
  }

  public alterarNota(titulo, nota) {
    this.firebaseService.alterarNota(this.idAlteracao, titulo.value, nota.value);
    this.cancelarAlteracao();
  }

  public cancelarAlteracao() {
    this.idAlteracao = null;
    this.titulo.value = '';
    this.anotacao.value = '';
  }

  public async logout() {
    await this.firebaseService.logout();
    this.router.navigateByUrl('login');
  }

}
