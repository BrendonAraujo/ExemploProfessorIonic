import { Injectable } from '@angular/core';
import {AngularFirestore} from "@angular/fire/compat/firestore";
import {map} from "rxjs/operators";
import {AngularFireAuth} from "@angular/fire/compat/auth";
import {createUserWithEmailAndPassword} from "@angular/fire/auth";
import {BehaviorSubject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {

  private usuario;

  private usuarioSubject: BehaviorSubject<any|null>;

  constructor(private firebase:AngularFirestore,
              private auth:AngularFireAuth) {

    this.auth.authState.subscribe( user => {
      if (user) {
        this.carregarUsuario(user.uid);
      } else {
        this.usuario = null;
        this.usuarioSubject. next(null);
      }
    })

  }

  public registrar(email, senha, nome) {
    return this.auth.createUserWithEmailAndPassword(email, senha).then((userCredential)  => {
      this.firebase
        .collection('usuarios')
        .doc(userCredential.user.uid)
        .set({
          nome,
          email
        })

    });
  }

  public logout() {
    return this.auth.signOut();
  }

  public login(email, senha) {
    return this.auth.signInWithEmailAndPassword(email, senha);
  }

  public getUsuarioAutenticado() {
    this.usuarioSubject = new BehaviorSubject<any>(this.usuario);
    return this.usuarioSubject
  }

  public getNotasDoDia() {
    return this.firebase.collection('usuarios')
      .doc(this.usuario.id)
      .collection('notas', ref => ref
        .where('criadoEm','==', new Date()))
      .snapshotChanges()
      .pipe(map(actions => actions.map(a => {
        const id = a.payload.doc.id;
        const dado:any = a.payload.doc.data();
        return {id,...dado};
      })));
  }


  public getNotas() {
    return this.firebase.collection('usuarios')
      .doc(this.usuario.id)
      .collection('notas')
      .snapshotChanges()
      .pipe(map(actions => actions.map(a => {
        const id = a.payload.doc.id;
        const dado:any = a.payload.doc.data();
        return {id,...dado};
      })));
    // .valueChanges();
  }

  public adicionarNota(titulo, nota) {
    return this.firebase
      .collection('usuarios')
      .doc(this.usuario.id)
      .collection('notas')
      .add({
        titulo,
        anotacao: nota,
        criadoEm: new Date()
      })
  }

  public removerNota(id) {
    return this.firebase
      .collection('usuarios')
      .doc(this.usuario.id)
      .collection('notas')
      .doc(id)
      .delete();
  }

  public alterarNota(id, titulo, anotacao) {
    return this.firebase
      .collection('usuarios')
      .doc(this.usuario.id)
      .collection('notas')
      .doc(id)
      .update({titulo, anotacao})
  }


  private async carregarUsuario(id) {
    const docRef = await this.firebase
      .collection('usuarios')
      .doc(id)
      .get().toPromise();

    this.usuario = {id, ...docRef.data() as any};
    this.usuarioSubject.next(this.usuario);
    console.log(this.usuario);
  }
}
