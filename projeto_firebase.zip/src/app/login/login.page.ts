import { Component, OnInit } from '@angular/core';
import {FirebaseService} from "../services/firebase.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  constructor(private firebaseService:FirebaseService,
              private router: Router) { }

  ngOnInit() {
  }

  public async login(email, senha) {
    /*
    this.firebaseService.login(email,senha).catch(error => {
      console.log(error);
    })
    */

    try {
      await this.firebaseService.login(email, senha);
      this.router.navigateByUrl('home');
    }catch (e) {
      console.log(e);
    }
  }

}
